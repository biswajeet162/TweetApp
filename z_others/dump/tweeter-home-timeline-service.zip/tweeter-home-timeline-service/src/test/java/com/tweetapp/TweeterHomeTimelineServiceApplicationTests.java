package com.tweetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweeterHomeTimelineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
